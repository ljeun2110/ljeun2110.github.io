---
title: "Post: Future Date"
date: 9999-12-31
categories:
  - Post
---

This post lives in the future and is dated {{ page.date | date: "%c" }}. When building Jekyll with the `--future` flag it should appear.